﻿using IMIFileGeneratorOutboundScheduler.HelperClasses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace IMIFileGeneratorOutboundScheduler
{


    public class DMKMap
    {
        public string strDpkValue;
        public List<string> lstProcessKeys;
    }

    public class IMIPositionMap
    {
        public string strImiKeyword;
        public string strPosition;

    }

   public class ProcessDirectories
    {

        public void DPKMappingCsv()
        {
            string fileName = ConfigurationManager.AppSettings["DPKMapping"];
            using (var stream = File.OpenRead(fileName))
            using (var reader = new StreamReader(stream))
            {
                var data = CsvParser.ParseHeadAndTail(reader, ',', '"');
                var header = data.Item1;
                var lines = data.Item2;
                DMKMap objdmi = null;
                List<string> lstprocKeys = null;
                Dictionary<string, DMKMap> _dicDmiMaps = new Dictionary<string, DMKMap>();                  
                foreach (var line in lines)
                { 
                    string[] linekeys = line[1].Split(',');
                    lstprocKeys = new List<string>();
                    objdmi = new DMKMap();
                    lstprocKeys.Add(linekeys[0]);
                    lstprocKeys.Add(linekeys[1]);
                    objdmi.strDpkValue = line[0];
                    objdmi.lstProcessKeys = lstprocKeys;
                    _dicDmiMaps.Add(objdmi.strDpkValue, objdmi);
                    //for (var i = 0; i < header.Count; i++)
                    //    if (!string.IsNullOrEmpty(line[i]))
                    //        Console.WriteLine("{0}={1}", header[i], line[i]);
                    //Console.WriteLine();
                }
            }
        }
       
    }
}
